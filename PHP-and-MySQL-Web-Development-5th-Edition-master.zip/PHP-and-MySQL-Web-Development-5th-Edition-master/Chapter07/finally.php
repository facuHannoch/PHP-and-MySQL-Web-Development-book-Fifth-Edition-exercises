<?php
  try {
    // do something, maybe throw some exceptions
  } catch (Exception $e) {
    // handle exception
  } finally {
    echo "Always runs!";
  }
?>
