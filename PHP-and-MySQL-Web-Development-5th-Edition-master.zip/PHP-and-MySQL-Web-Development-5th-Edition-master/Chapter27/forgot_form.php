<?php
 require_once('bookmark_fns.php');
 do_html_header('Reset password');
 
 display_forgot_form();

 do_html_footer();
?>
